#include "polygon.hpp"
#include <iostream>
#include <dlfcn.h>

int main() {
    using std::cout;
    using std::cerr;

    // triangle k�t�phanesini y�kle
    void* triangle = dlopen("./triangle.so", RTLD_LAZY);
    if (!triangle) {
        cerr << "Cannot load library: " << dlerror() << '\n';
        return 1;
    }

    // hatalar� resetle
    dlerror();
    
    // sembolleri y�kle
    create_t* create_triangle = (create_t*) dlsym(triangle, "create");
    const char* dlsym_error = dlerror();
    if (dlsym_error) {
        cerr << "Cannot load symbol create: " << dlsym_error << '\n';
        return 1;
    }
    
    destroy_t* destroy_triangle = (destroy_t*) dlsym(triangle, "destroy");
    dlsym_error = dlerror();
    if (dlsym_error) {
        cerr << "Cannot load symbol destroy: " << dlsym_error << '\n';
        return 1;
    }

    // s�n�f�n bir �rne�ini yarat
    polygon* poly = create_triangle();

    //s�n�f� kullan
    poly->set_side_length(7);
        cout << "The area is: " << poly->area() << '\n';

    // s�n�f� yoket
    destroy_triangle(poly);

    // triangle k�t�phanesini bo�alt (unload)
    dlclose(triangle);
}
